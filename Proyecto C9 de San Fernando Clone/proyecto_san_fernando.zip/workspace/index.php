<link href="https://fonts.googleapis.com/css?family=Coiny|Slabo+27px&amp;subset=latin-ext,tamil,vietnamese" rel="stylesheet">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <title>Pagina Principal - San Fernando</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/estilos.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/animate.css" />

    <script src="main.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>

<body>

        

    <header>
        <h1 class="titulo animated rubberBand delay-2s infinite ">San Fernando</h1>
        <h3 class="subtitulo ">Planta Beneficio Huaral</h3>
        
        <img src="http://3.bp.blogspot.com/_yKt1IQlZj1M/Ss41yW3F2oI/AAAAAAAAADQ/qMemNKWwHYg/s400/grupo+san+fernando.bmp" class="img-rounded" alt="foto-san-fernando"></img>
        <br><br>
        <a href="vista/login.php" class="boton">INGRESAR</a>
    </header>  



</body>
</html>